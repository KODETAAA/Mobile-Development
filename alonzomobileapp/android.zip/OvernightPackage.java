package com.example.alonzomobileapp;

public class OvernightPackage extends Package {
    private double addFee = 250.50;

    public OvernightPackage(){
    }

    public OvernightPackage(String sname, String saddress, String rname, String raddress, double weight, double cost, double addFee){
        super(sname,saddress,rname,raddress,weight,cost);
        this.addFee = addFee;
    }

    public void setAddFee(double addFee) {
        this.addFee = addFee;
    }

    public double getAddFee() {
        return addFee;
    }

    public double calculateCost(){
        double addFee = getAddFee() + (getWeight() * getCost());
        return addFee;
    }
}
