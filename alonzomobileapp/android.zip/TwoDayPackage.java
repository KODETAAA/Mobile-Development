package com.example.alonzomobileapp;

import android.widget.Toast;

public class TwoDayPackage extends Package {
    private double fee = 150.50;

    public TwoDayPackage() {
    }

    public TwoDayPackage(String sname, String saddress, String rname, String raddress, double weight, double cost, double fee) {
        super(sname, saddress, rname, raddress, weight, cost);
        this.fee = fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public double getFee() {
        return fee;
    }

    public  double calculateCost() {
        double fee = getWeight() * getCost() + getFee();
        return fee;
    }

}
