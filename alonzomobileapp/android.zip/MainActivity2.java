package com.example.alonzomobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity  implements View.OnClickListener {

    Button btnPackage, btnOneDay, btnOver, btnCalculate;
    EditText txtPackage, txtSenderName, txtSenderAddress, txtReceiverName, txtReceiverAddress, txtWeight, txtCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        btnOneDay = (Button) findViewById(R.id.btnOneDay);
        btnOver = (Button) findViewById(R.id.btnOver);
        btnCalculate = (Button) findViewById(R.id.btnCalculate);

        txtPackage = (EditText) findViewById(R.id.txtPackage);
        txtSenderName = (EditText) findViewById(R.id.txtSender);
        txtSenderAddress = (EditText) findViewById(R.id.txtSAddress);
        txtReceiverName = (EditText) findViewById(R.id.txtReceiver);
        txtReceiverAddress = (EditText) findViewById(R.id.txtRAddress);
        txtWeight = (EditText) findViewById(R.id.txtWeight);
        txtCost = (EditText) findViewById(R.id.txtCost);


        btnPackage.setOnClickListener(this);
        btnOneDay.setOnClickListener(this);
        btnOver.setOnClickListener(this);
        btnCalculate.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        DecimalFormat df = new DecimalFormat("#.##");
        String pack = txtPackage.getText().toString();
        String sn = txtSenderName.getText().toString();
        String sa = txtSenderAddress.getText().toString();
        String rn = txtReceiverName.getText().toString();
        String ra = txtReceiverAddress.getText().toString();
        double weight = Double.parseDouble(String.valueOf(txtWeight.getText()));
        double cost = Double.parseDouble(String.valueOf(txtCost.getText()));


        switch (v.getId()) {

            case R.id.btnOneDay:
                txtPackage.setText("OneDay Package");
                break;
            case R.id.btnOver:
                txtPackage.setText("Overnight Package");
                break;
            case R.id.btnCalculate:

                if (txtPackage.getText().equals("OneDay Package")){
                    TwoDayPackage td = new TwoDayPackage(sn, sa, rn, ra, weight, cost, 150.50);
                    double CostA = td.calculateCost();
                    txtCost.setText(String.valueOf(df.format(CostA)));

                } else if (txtPackage.getText().equals("Overnight Package")){
                    OvernightPackage po = new OvernightPackage(sn, sa, rn, ra, weight, cost, 250.50);
                    double CostB = po.calculateCost();
                    txtCost.setText(String.valueOf(df.format(CostB)));
                }


        }


    }
}